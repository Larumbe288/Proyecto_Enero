# Atlantis-Lite

![](http://themekita.com/assets/images/atlantislite.png)

Free Bootstrap 4 Admin Dashboard

Atlantis Lite is a free bootstrap 4 admin dashboard that is beautifully and elegantly designed to display various metrics, numbers or data visualization.

Atlantis Lite admin dashboard has 2 layouts, many plugins and UI components to help developers create dashboards quickly and effectively so they can save development time and also help users to make the right and fast decisions based on existing data.

We made documentation how you started using this dashboard template and use available components and plugins.
